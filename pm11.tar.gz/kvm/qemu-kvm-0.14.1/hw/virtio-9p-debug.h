#ifndef _QEMU_VIRTIO_9P_DEBUG_H
#define _QEMU_VIRTIO_9P_DEBUG_H

void pprint_pdu(V9fsPDU *pdu);

#endif
