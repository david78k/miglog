#ifndef _SH7750_REGNAMES_H
#define _SH7750_REGNAMES_H

const char *regname(uint32_t addr);

#endif				/* _SH7750_REGNAMES_H */
