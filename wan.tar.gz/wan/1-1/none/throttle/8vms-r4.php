<html>
<head>

</head>
<title>8vms-r4</title>
<body>

<h2>Single host controller AIMD 8vms-r4 (<a href=../>../UP</a>)</h2>

<a href=8vms-r4.png><img src=8vms-r4.png></a>
<a href=8vms-r4.tiff><img src=8vms-r4.tiff></a>
<br />

<a href=8vms-r4.eps>download 8vms-r4.eps</a>
<br />
<a href=8vms-r4.tar>download all (8vms-r4.png, 8vms-r4.dat, 8vms-r4.p)</a>
<br />

<a href=8vms-r4.dat>8vms-r4.dat (data file)</a>
<?php
$str = file_get_contents("8vms-r4.dat");
echo "<pre>$str</pre>";
?>

<a href=8vms-r4.dstat>8vms-r4.dstat (network data file)</a>
<?php
$str = file_get_contents("8vms-r4.dstat");
echo "<pre>$str</pre>";
?>

<a href=8vms-r4.p>8vms-r4.p (gnuplot script file)</a>
<?php $str = file_get_contents ("8vms-r4.p");
echo "<pre>$str</pre>";
?>

<a href=8vms-r4.log>8vms-r4-r*.log (log files)</a>

<a href=8vms-r4.net>8vms-r4.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("8vms-r4.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

