<html>
<head>

</head>
<title>7vms-r5</title>
<body>

<h2>Single host controller AIMD 7vms-r5 (<a href=../>../UP</a>)</h2>

<a href=7vms-r5.png><img src=7vms-r5.png></a>
<a href=7vms-r5.tiff><img src=7vms-r5.tiff></a>
<br />

<a href=7vms-r5.eps>download 7vms-r5.eps</a>
<br />
<a href=7vms-r5.tar>download all (7vms-r5.png, 7vms-r5.dat, 7vms-r5.p)</a>
<br />

<a href=7vms-r5.dat>7vms-r5.dat (data file)</a>
<?php
$str = file_get_contents("7vms-r5.dat");
echo "<pre>$str</pre>";
?>

<a href=7vms-r5.dstat>7vms-r5.dstat (network data file)</a>
<?php
$str = file_get_contents("7vms-r5.dstat");
echo "<pre>$str</pre>";
?>

<a href=7vms-r5.p>7vms-r5.p (gnuplot script file)</a>
<?php $str = file_get_contents ("7vms-r5.p");
echo "<pre>$str</pre>";
?>

<a href=7vms-r5.log>7vms-r5-r*.log (log files)</a>

<a href=7vms-r5.net>7vms-r5.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("7vms-r5.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

