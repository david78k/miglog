<html>
<head>

</head>
<title>6vms-r5</title>
<body>

<h2>Single host controller AIMD 6vms-r5 (<a href=../>../UP</a>)</h2>

<a href=6vms-r5.png><img src=6vms-r5.png></a>
<a href=6vms-r5.tiff><img src=6vms-r5.tiff></a>
<br />

<a href=6vms-r5.eps>download 6vms-r5.eps</a>
<br />
<a href=6vms-r5.tar>download all (6vms-r5.png, 6vms-r5.dat, 6vms-r5.p)</a>
<br />

<a href=6vms-r5.dat>6vms-r5.dat (data file)</a>
<?php
$str = file_get_contents("6vms-r5.dat");
echo "<pre>$str</pre>";
?>

<a href=6vms-r5.dstat>6vms-r5.dstat (network data file)</a>
<?php
$str = file_get_contents("6vms-r5.dstat");
echo "<pre>$str</pre>";
?>

<a href=6vms-r5.p>6vms-r5.p (gnuplot script file)</a>
<?php $str = file_get_contents ("6vms-r5.p");
echo "<pre>$str</pre>";
?>

<a href=6vms-r5.log>6vms-r5-r*.log (log files)</a>

<a href=6vms-r5.net>6vms-r5.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("6vms-r5.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

