<html>
<head>

</head>
<title>10vms-r14</title>
<body>

<h2>WAN 10vms-r14 (<a href=../>../UP</a>)</h2>

<a href=10vms-r14.png><img src=10vms-r14.png></a>
<a href=10vms-r14-net.png><img src=10vms-r14-net.png></a>
<br />

<a href=10vms-r14.eps>download 10vms-r14.eps</a>, 
<a href=10vms-r14-net.eps>download 10vms-r14-net.eps</a>
<br />
<a href=10vms-r14.tar>download all (10vms-r14.png, 10vms-r14.dat, 10vms-r14.p)</a>
<br />

<a href=10vms-r14.dat>10vms-r14.dat (data file)</a>
<?php
$str = file_get_contents("10vms-r14.dat");
echo "<pre>$str</pre>";
?>

<a href=10vms-r14.dstat>10vms-r14.dstat (network raw data file)</a>, 
<a href=10vms-r14-net.dat>10vms-r14-net.dat (network modified data file)</a>
<?php
$str = file_get_contents("10vms-r14.dstat");
echo "<pre>$str</pre>";
?>

<a href=10vms-r14.log>10vms-r14-r*.log (log files)</a>

<a href=10vms-r14.net>10vms-r14.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("10vms-r14.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

