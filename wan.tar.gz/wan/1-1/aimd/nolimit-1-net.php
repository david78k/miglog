<html>
<head>

</head>
<title>nolimit-1-net</title>
<body>

<h2>Single host controller AIMD nolimit-1-net (<a href=../>../UP</a>)</h2>

<a href=nolimit-1-net.png><img src=nolimit-1-net.png></a>
<a href=nolimit-1-net.tiff><img src=nolimit-1-net.tiff></a>
<br />

<a href=nolimit-1-net.eps>download nolimit-1-net.eps</a>
<br />
<a href=nolimit-1-net.tar>download all (nolimit-1-net.png, nolimit-1-net.dat, nolimit-1-net.p)</a>
<br />

<a href=nolimit-1-net.dat>nolimit-1-net.dat (data file)</a>
<?php
$str = file_get_contents("nolimit-1-net.dat");
echo "<pre>$str</pre>";
?>

<a href=nolimit-1-net.p>nolimit-1-net.p (gnuplot script file)</a>
<?php $str = file_get_contents ("nolimit-1-net.p");
echo "<pre>$str</pre>";
?>

<a href=nolimit-1-net.log>nolimit-1-net-r*.log (log files)</a>

<a href=nolimit-1-net.net>nolimit-1-net.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("nolimit-1-net.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

