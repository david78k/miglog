<html>
<head>

</head>
<title>nolimit-2-net</title>
<body>

<h2>Single host controller AIMD nolimit-2-net (<a href=../>../UP</a>)</h2>

<a href=nolimit-2-net.png><img src=nolimit-2-net.png></a>
<a href=nolimit-2-net.tiff><img src=nolimit-2-net.tiff></a>
<br />

<a href=nolimit-2-net.eps>download nolimit-2-net.eps</a>
<br />
<a href=nolimit-2-net.tar>download all (nolimit-2-net.png, nolimit-2-net.dat, nolimit-2-net.p)</a>
<br />

<a href=nolimit-2-net.dat>nolimit-2-net.dat (data file)</a>
<?php
$str = file_get_contents("nolimit-2-net.dat");
echo "<pre>$str</pre>";
?>

<a href=nolimit-2-net.dstat>nolimit-2-net.dstat (network data file)</a>
<?php
$str = file_get_contents("nolimit-2-net.dstat");
echo "<pre>$str</pre>";
?>

<a href=nolimit-2-net.p>nolimit-2-net.p (gnuplot script file)</a>
<?php $str = file_get_contents ("nolimit-2-net.p");
echo "<pre>$str</pre>";
?>

<a href=nolimit-2-net.log>nolimit-2-net-r*.log (log files)</a>

<a href=nolimit-2-net.net>nolimit-2-net.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("nolimit-2-net.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

