<html>
<head>

</head>
<title>nolimit-1</title>
<body>

<h2>Single host controller AIMD nolimit-1 (<a href=../>../UP</a>)</h2>

<a href=nolimit-1.png><img src=nolimit-1.png></a>
<a href=nolimit-1.tiff><img src=nolimit-1.tiff></a>
<br />

<a href=nolimit-1.eps>download nolimit-1.eps</a>
<br />
<a href=nolimit-1.tar>download all (nolimit-1.png, nolimit-1.dat, nolimit-1.p)</a>
<br />

<a href=nolimit-1.dat>nolimit-1.dat (data file)</a>
<?php
$str = file_get_contents("nolimit-1.dat");
echo "<pre>$str</pre>";
?>

<a href=nolimit-1.p>nolimit-1.p (gnuplot script file)</a>
<?php $str = file_get_contents ("nolimit-1.p");
echo "<pre>$str</pre>";
?>

<a href=nolimit-1.log>nolimit-1-r*.log (log files)</a>

<a href=nolimit-1.net>nolimit-1.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("nolimit-1.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

