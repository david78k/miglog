<html>
<head>

</head>
<title>1-1 WAN AIMD</title>
<body>

<h2>Single host 1-1 in WAN AIMD (<a href=../>../UP</a>)</h2>

<pre>
40VMs: r6 (314), r9(221), r5 (333), r7 (250)
#round time throughput 
r6 457.55 314
r9 651.14 221
r5 431.46 333
r7 573.53 250

- threshold 4: r10
50VMs: r8, r11, r13 (pm11)
- pm11: r12 (failed), r13
CA: r4, nolimit-1, nolimit-2, r2 (from 8), r3 (from 9), 
</pre>

<h3>1. <a href=125/>No-limit (125MB/s) 40VMs</a></h3>
