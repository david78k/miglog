<html>
<head>

</head>
<title>14vms-r7</title>
<body>

<h2>WAN 14vms-r7 (<a href=../>../UP</a>)</h2>

<a href=14vms-r7.png><img src=14vms-r7.png></a>
<a href=14vms-r7-net.png><img src=14vms-r7-net.png></a>
<br />

<a href=14vms-r7.eps>download 14vms-r7.eps</a>, 
<a href=14vms-r7-net.eps>download 14vms-r7-net.eps</a>
<br />
<a href=14vms-r7.tar>download all (14vms-r7.png, 14vms-r7.dat, 14vms-r7.p)</a>
<br />

<a href=14vms-r7.dat>14vms-r7.dat (data file)</a>
<?php
$str = file_get_contents("14vms-r7.dat");
echo "<pre>$str</pre>";
?>

<a href=14vms-r7.dstat>14vms-r7.dstat (network raw data file)</a>, 
<a href=14vms-r7-net.dat>14vms-r7-net.dat (network modified data file)</a>
<?php
$str = file_get_contents("14vms-r7.dstat");
echo "<pre>$str</pre>";
?>

<a href=14vms-r7.log>14vms-r7-r*.log (log files)</a>

<a href=14vms-r7.net>14vms-r7.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("14vms-r7.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

