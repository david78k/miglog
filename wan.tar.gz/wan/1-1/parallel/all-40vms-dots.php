<html>
<head>

</head>
<title>all-40vms-dots</title>
<body>

<h2>WAN simulation all-40vms-dots (<a href=../>../UP</a>)</h2>

<a href=all-40vms-dots.png><img src=all-40vms-dots.png></a>
<a href=all-40vms-dots-detail.png><img src=all-40vms-dots-detail.png></a>
<a href=all-40vms-dots-net.png><img src=all-40vms-dots-net.png></a>
<br />

<a href=all-40vms-dots.eps>download all-40vms-dots.eps</a>, 
<a href=all-40vms-dots.emf>download all-40vms-dots.emf</a>,
<a href=all-40vms-dots-net.eps>download all-40vms-dots-net.eps</a>
<br />
<a href=all-40vms-dots.tar>download all (all-40vms-dots.png, all-40vms-dots.dat, all-40vms-dots.p)</a>
<br />

<a href=all-40vms-dots.dat>all-40vms-dots.dat (data file)</a>
<?php
$str = file_get_contents("all-40vms-dots.dat");
echo "<pre>$str</pre>";
?>

<a href=all-40vms-dots.dstat>all-40vms-dots.dstat (network raw data file)</a>, 
<a href=all-40vms-dots-net.dat>all-40vms-dots-net.dat (network modified data file)</a>
<?php
$str = file_get_contents("all-40vms-dots.dstat");
echo "<pre>$str</pre>";
?>

<a href=all-40vms-dots.log>all-40vms-dots-r*.log (log files)</a>

<a href=all-40vms-dots.net>all-40vms-dots.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("all-40vms-dots.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

