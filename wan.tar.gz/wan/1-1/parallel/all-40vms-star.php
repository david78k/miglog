<html>
<head>

</head>
<title>all-40vms-star</title>
<body>

<h2>WAN simulation all-40vms-star (<a href=../>../UP</a>)</h2>

<a href=all-40vms-star.png><img src=all-40vms-star.png></a>
<a href=all-40vms-star-detail.png><img src=all-40vms-star-detail.png></a>
<a href=all-40vms-star-net.png><img src=all-40vms-star-net.png></a>
<br />

<a href=all-40vms-star.eps>download all-40vms-star.eps</a>, 
<a href=all-40vms-star.emf>download all-40vms-star.emf</a>,
<a href=all-40vms-star-net.eps>download all-40vms-star-net.eps</a>
<br />
<a href=all-40vms-star.tar>download all (all-40vms-star.png, all-40vms-star.dat, all-40vms-star.p)</a>
<br />

<a href=all-40vms-star.dat>all-40vms-star.dat (data file)</a>
<?php
$str = file_get_contents("all-40vms-star.dat");
echo "<pre>$str</pre>";
?>

<a href=all-40vms-star.dstat>all-40vms-star.dstat (network raw data file)</a>, 
<a href=all-40vms-star-net.dat>all-40vms-star-net.dat (network modified data file)</a>
<?php
$str = file_get_contents("all-40vms-star.dstat");
echo "<pre>$str</pre>";
?>

<a href=all-40vms-star.log>all-40vms-star-r*.log (log files)</a>

<a href=all-40vms-star.net>all-40vms-star.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("all-40vms-star.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

