<html>
<head>

</head>
<title>all-40vms-x</title>
<body>

<h2>WAN simulation all-40vms-x (<a href=../>../UP</a>)</h2>

<a href=all-40vms-x.png><img src=all-40vms-x.png></a>
<a href=all-40vms-x-detail.png><img src=all-40vms-x-detail.png></a>
<a href=all-40vms-x-net.png><img src=all-40vms-x-net.png></a>
<br />

<a href=all-40vms-x.eps>download all-40vms-x.eps</a>, 
<a href=all-40vms-x.emf>download all-40vms-x.emf</a>,
<a href=all-40vms-x-net.eps>download all-40vms-x-net.eps</a>
<br />
<a href=all-40vms-x.tar>download all (all-40vms-x.png, all-40vms-x.dat, all-40vms-x.p)</a>
<br />

<a href=all-40vms-x.dat>all-40vms-x.dat (data file)</a>
<?php
$str = file_get_contents("all-40vms-x.dat");
echo "<pre>$str</pre>";
?>

<a href=all-40vms-x.dstat>all-40vms-x.dstat (network raw data file)</a>, 
<a href=all-40vms-x-net.dat>all-40vms-x-net.dat (network modified data file)</a>
<?php
$str = file_get_contents("all-40vms-x.dstat");
echo "<pre>$str</pre>";
?>

<a href=all-40vms-x.log>all-40vms-x-r*.log (log files)</a>

<a href=all-40vms-x.net>all-40vms-x.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("all-40vms-x.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

