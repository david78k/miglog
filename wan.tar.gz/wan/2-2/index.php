<html>
<head>

</head>
<title>2-2 WAN</title>
<body>

<h2>Multiple hosts 2-2 WAN AIST to UF (<a href=../>../up</a>)</h2>

<h3>1. <a href=sysid/>System identification</a></h3>
Max speed <font color=red>116.5</font> for eth1 (233/2 total)MB/s out of 125MB/s = 1000Mbps
<br />
Delay between AIST and UF = 179ms
<br />

<h3>2. <a href=aimd/>AIMD controller</a></h3>
<h3>3. <a href=none/>Controller none</a></h3>

<!--
<h3>3. <a href=controller/basic/>Basic controller</a></h3>
<h3>4. <a href=controller/aiad/>AIAD controller</a></h3>
-->
