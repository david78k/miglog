<html>
<head>

</head>
<title>r1-2</title>
<body>

<h2>Single host controller AIMD r1-2 (<a href=../>../UP</a>)</h2>

<a href=r1-2.png><img src=r1-2.png></a>
<a href=r1-2.tiff><img src=r1-2.tiff></a>
<br />

<a href=r1-2.eps>download r1-2.eps</a>
<br />
<a href=r1-2.tar>download all (r1-2.png, r1-2.dat, r1-2.p)</a>
<br />

<a href=r1-2.dat>r1-2.dat (data file)</a>
<?php
$str = file_get_contents("r1-2.dat");
echo "<pre>$str</pre>";
?>

<a href=r1-2.dstat>r1-2.dstat (network data file)</a>
<?php
$str = file_get_contents("r1-2.dstat");
echo "<pre>$str</pre>";
?>

<a href=r1-2.p>r1-2.p (gnuplot script file)</a>
<?php $str = file_get_contents ("r1-2.p");
echo "<pre>$str</pre>";
?>

<a href=r1-2.log>r1-2-r*.log (log files)</a>

<a href=r1-2.net>r1-2.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("r1-2.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

