<html>
<head>

</head>
<title>r2-2</title>
<body>

<h2>Single host controller AIMD r2-2 (<a href=../>../UP</a>)</h2>

<a href=r2-2.png><img src=r2-2.png></a>
<a href=r2-2.tiff><img src=r2-2.tiff></a>
<br />

<a href=r2-2.eps>download r2-2.eps</a>
<br />
<a href=r2-2.tar>download all (r2-2.png, r2-2.dat, r2-2.p)</a>
<br />

<a href=r2-2.dat>r2-2.dat (data file)</a>
<?php
$str = file_get_contents("r2-2.dat");
echo "<pre>$str</pre>";
?>

<a href=r2-2.dstat>r2-2.dstat (network data file)</a>
<?php
$str = file_get_contents("r2-2.dstat");
echo "<pre>$str</pre>";
?>

<a href=r2-2.p>r2-2.p (gnuplot script file)</a>
<?php $str = file_get_contents ("r2-2.p");
echo "<pre>$str</pre>";
?>

<a href=r2-2.log>r2-2-r*.log (log files)</a>

<a href=r2-2.net>r2-2.net (dstat -cnm file)</a>
<?php
$str = file_get_contents("r2-2.net");
echo "<pre>$str</pre>";
?>

<br />

</body>
</html>

